define([
    'M2ePro/Magento/Product/Grid'
], function () {

    window.ListingProductGrid = Class.create(MagentoProductGrid, {

        // ---------------------------------------

        // ---------------------------------------

    });

});