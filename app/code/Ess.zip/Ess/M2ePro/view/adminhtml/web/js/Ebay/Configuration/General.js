define(['knockout'], function(ko){
    return {
        mode: ko.observable()
    }
});