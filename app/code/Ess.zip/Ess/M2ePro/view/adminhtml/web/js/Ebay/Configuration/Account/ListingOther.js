define(['knockout'], function(ko){
    return {
        synchronization: ko.observable(),
        mappingMode: ko.observable(),
        mappingSkuMode: ko.observable(),
        mappingTitleMode: ko.observable(),
    }
});