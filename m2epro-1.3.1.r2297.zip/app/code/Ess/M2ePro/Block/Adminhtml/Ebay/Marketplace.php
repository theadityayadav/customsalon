<?php

/*
 * @author     M2E Pro Developers Team
 * @copyright  2011-2015 ESS-UA [M2E Pro]
 * @license    Commercial use is forbidden
 */

namespace Ess\M2ePro\Block\Adminhtml\Ebay;

use Ess\M2ePro\Block\Adminhtml\Magento\Form\AbstractContainer;

class Marketplace extends AbstractContainer
{
    //########################################

    public function _construct()
    {
        parent::_construct();

        // Initialization block
        // ---------------------------------------
        $this->_controller = 'adminhtml_ebay_marketplace';
        // ---------------------------------------

        $this->removeButton('save');
        $this->removeButton('reset');
        $this->removeButton('back');

        $this->addButton('run_update_all', array(
            'label'     => $this->__('Update All Now'),
            'onclick'   => 'MarketplaceObj.updateAction()',
            'class'     => 'save update_all_marketplaces primary'
        ));

        $this->addButton('run_save_and_synch', array(
            'label'     => $this->__('Save'),
            'onclick'   => 'MarketplaceObj.saveAction();',
            'class'     => 'save save_and_update_marketplaces primary'
        ));
    }

    //########################################

    protected function _prepareLayout()
    {
        $this->appendHelpBlock([
            'content' => $this->__(
                '<p>This Page contains a list of eBay international Marketplaces where you
                can sell your Items.</p><br>
                <p><strong>Enable</strong> only those Marketplaces that you want to sell on.
                High number of enabled Marketplaces will take longer to process the necessary data.</p>'
            )
        ]);

        return parent::_prepareLayout();
    }

    protected function _toHtml()
    {
        return
            '<div id="marketplaces_progress_bar"></div>' .
            '<div id="marketplaces_content_container">' .
            parent::_toHtml() .
            '</div>';
    }

    //########################################
}