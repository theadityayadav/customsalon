<?php

/*
 * @author     M2E Pro Developers Team
 * @copyright  2011-2016 ESS-UA [M2E Pro]
 * @license    Commercial use is forbidden
 */

namespace Ess\M2ePro\Block\Adminhtml\Ebay\Log\Listing\Other\View\Separated;

use Ess\M2ePro\Block\Adminhtml\Log\Listing\Other\View\Separated\AbstractGrid;
use Ess\M2ePro\Block\Adminhtml\Ebay\Log\Listing\Other\GridTrait;

class Grid extends AbstractGrid
{
    //########################################

    use GridTrait;

    //########################################
}